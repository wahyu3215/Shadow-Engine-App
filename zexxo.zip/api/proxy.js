import axios from 'axios';

export default async function handler(req, res) {
    // IP Pterodactyl lu
    const TARGET_SERVER = 'http://128.199.30.186:3000';

    // Ambil path dari query, misal: /api/anime/search?q=naruto
    const { path } = req.query;

    if (!path) {
        return res.status(400).json({ error: 'Path missing' });
    }

    try {
        const fullUrl = `${TARGET_SERVER}${path}`;
        
        const queryParams = { ...req.query };
        delete queryParams.path;

        const response = await axios.get(fullUrl, { 
            params: queryParams,
            timeout: 10000 
        });

        res.status(200).json(response.data);
    } catch (error) {
        console.error("Proxy Error:", error.message);
        res.status(500).json({ 
            status: false, 
            error: 'Gagal menghubungi Server Backend (Pterodactyl mungkin offline)',
            details: error.message 
        });
    }
}
